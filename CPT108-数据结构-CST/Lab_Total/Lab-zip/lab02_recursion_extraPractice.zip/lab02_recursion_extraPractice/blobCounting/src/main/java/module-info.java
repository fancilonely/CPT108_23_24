/**
 * CPT108 Laboratory: Recursion - Blob counting
 */
module xjtlu.cpt108lab.recursion.blobCounting {
}

package xjtlu.cpt108.treasurehunting;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import xjtlu.cpt108.util.FileManager;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TreasureHuntingTest {

	private final static String FILE_SRC_ROOT = "src/main/java/";
	private final static String TRAP_FILE = "xjtlu/cpt108/treasurehunting/Trap.java";

	private static boolean verifyFileContent() {
		try {
			String content = FileManager.read(new File(FILE_SRC_ROOT + TRAP_FILE));
			if (-1875483498 != content.hashCode()) {
				System.err.println("Treasure file " + TRAP_FILE + " has been modified!");
				return false;
			}
			isFileVerified = true;
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	private static void setReturnCode(ByteArrayOutputStream baos) {
		StringBuilder sb = new StringBuilder();
		for (String str : baos.toString().split("\n")) {
			System.out.println(str);
			String[] s = str.split("!");
			if (s.length > 1) sb.append(s[1].strip());
		}
		returnCode = sb.toString().hashCode();
	}

	private static boolean isFileVerified;
	private static int returnCode;

	@BeforeAll
	private static void beforeAll() {
		isFileVerified = false;
	}

	@BeforeEach
	private void beforeEach() {
		returnCode = -1;
	}

	@Test
	@Order(1)
	public void phase1() {
		go(1);
		assertEquals(-1633853510, returnCode);
	}

	@Test
	@Order(2)
	public void phase2() {
		go(2);
		assertEquals(-1341057377, returnCode);
	}

	@Test
	@Order(3)
	public void phase3() {
		go(3);
		assertEquals(-397867533, returnCode);
	}

	private static void go(int phase) {
		if (!isFileVerified) assertTrue(verifyFileContent());

		PrintStream out = System.out;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		TreasureHunting.go(phase);
		System.setOut(out);

		setReturnCode(baos);
	}

}

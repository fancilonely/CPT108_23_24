package xjtlu.cpt108.treasurehunting;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import xjtlu.cpt108.util.StdRandom;

public class Trap {

	private static String shuffle(int seed, String str) {
		String code = "code" + str.hashCode();
		StdRandom.setSeed(seed);
		char[] chars = code.toCharArray();
		StdRandom.shuffle(chars);
		return String.valueOf(chars);
	}

	private static String shufflePassword(String str) {
		return shuffle(1234, str);
	}

	private List<Character> shufflePasswordInList(String str) {
		String code = "code" + str.hashCode();
		String passcode = shufflePassword(code);
		return (List<Character>) passcode.chars().mapToObj((c -> (char) c)).collect(Collectors.toList());
	}

	public void openTheGate(String passcode) {
		String correctPasscode = shufflePassword("hello");
		if (correctPasscode.equals(passcode)) System.out.println("Great! You have opened the gate!");
		else System.out.println("Password error! You cannot open the gate!");
	}

	public void enterTheTomb(String passcode) {
		List<Character> correctPasscode = shufflePasswordInList("hello");
		if (correctPasscode.size() != passcode.length()) {
			System.out.println("Password error! You cannot enter the tomb!");
			return;
		} else {
			for (int i = 0; i < correctPasscode.size(); i++) {
				if (correctPasscode.get(i) != passcode.charAt(i)) {
					System.out.println("Password error!!! You cannot enter the tomb!");
					return;
				}
			}
		}
		System.out.println("Great! You have entered the Tomb!");
	}

	public void unlockTreasureBox(String passcode) {
		Random random = new Random(1357);
		Set<Integer> numbers = new HashSet<Integer>();
		for (int i = 0; i < 10000; i++) {
			numbers.add(random.nextInt(100000));
		}

		int i = 0;
		int number = -1;
		Iterator<Integer> it = numbers.iterator();
		while (i++ < 2345 && it.hasNext()) {
			number = it.next();
		}

		if (number == Integer.parseInt(passcode)) System.out.println("Great! You have found the treasure!");
		else System.out.println("Oh...no! You cannot unlock the treasure box!");
	}

}

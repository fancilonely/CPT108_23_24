package xjtlu.cpt108.treasurehunting;

public class TreasureHunting {

	public static void go(int phase) {
		Trap trap = new Trap();
		switch (phase) {
		case 1 -> trap.openTheGate("Oh no! What is the password to open the door lock?");
		case 2 -> trap.enterTheTomb(null);
		case 3 -> trap.unlockTreasureBox("Password! I need the password to open the treasure box");
		default -> System.out.println("Unexpected phase value: " + phase);
		}
	}

}

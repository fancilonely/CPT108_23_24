/**
 * 
 */
module xjtlu.cpt108lab.collections.linkedList {
}
package xjtlu.cpt108.collections.linkedList;

import org.junit.jupiter.api.Test;

public class NodeTest {

	@Test
	public void simpleNodeTest() {
		Node node = new Node(11);
		System.out.println(node);
	}

}

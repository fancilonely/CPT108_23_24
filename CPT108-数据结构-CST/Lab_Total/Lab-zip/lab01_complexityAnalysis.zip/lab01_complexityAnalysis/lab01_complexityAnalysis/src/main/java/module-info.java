/**
 * 
 */
module xjtlu.cpt108lab.complexityAnalysis {
	requires com.olek.app.commons;
	requires xjtlu.cpt108.commons;
	requires xjtlu.cpt108.util.sort;
}

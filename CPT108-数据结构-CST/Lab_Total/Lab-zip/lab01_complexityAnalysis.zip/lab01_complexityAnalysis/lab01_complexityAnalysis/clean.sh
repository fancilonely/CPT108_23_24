#!/bin/sh

REPOSITORY=../repositories/maven
SOURCE_PATH=src/main/java

rm -f ${SOURCE_PATH}/xjtlu/cpt108/complexity/*.class
rm -f ${SOURCE_PATH}/module-info.class


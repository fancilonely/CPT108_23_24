/**
 * CPT108 Laboratory: Recursion - Palindrome
 */
module xjtlu.cpt108lab.recursion.palindrome {
}

package xjtlu.cpt108.recursion.palindrome;

public class Palindrome {

	public boolean verifyRecursive(String str) {
		throw new RuntimeException("Function not yet implmented!");
	}

	public boolean verifyIterative(String str) {
		throw new RuntimeException("Function not yet implmented!");
	}

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leapyearchecker;

import java.util.Scanner;

public class LeapYearChecker {
    public static void main(String[] args) {
        // 要查询的年份
          Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the array elements separated by commas: ");
        String year1 = scanner.nextLine();
        int year=Integer.parseInt(year1);
        // 调用方法判断是否为闰年
        boolean isLeapYear = isLeapYear(year);

        // 输出结果
        if (isLeapYear) {
            System.out.println(year + " is a leap year.");
        } else {
            System.out.println(year + " is not a leap year.");
        }
    }

    public static boolean isLeapYear(int year) {
        // Rule 1: If the year is evenly divisible by 4, go to Rule 2; otherwise, it is not a leap year.
        boolean divisibleBy4 = (year % 4 == 0);
        if (!divisibleBy4) {
            return false;
        }

        // Rule 2: If the year is evenly divisible by 100, go to Rule 3; otherwise it is a leap year.
        boolean divisibleBy100 = (year % 100 == 0);
        if (!divisibleBy100) {
            return true;
        }

        // Rule 3: If the year is evenly divisible by 400, then it is a leap year; otherwise, it is not a leap year.
        boolean divisibleBy400 = (year % 400 == 0);
        if (!divisibleBy400) {
            return false;
        }

        return false;
    }
}

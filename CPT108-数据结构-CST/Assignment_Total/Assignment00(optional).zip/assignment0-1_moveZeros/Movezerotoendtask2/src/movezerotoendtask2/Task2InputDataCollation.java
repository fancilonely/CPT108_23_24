package movezerotoendtask2;
import java.util.Random;

public class TestDataGeneration {
    public static void main(String[] args) {
        // Test the function with array size random
        double random = 10*Math.random()+1;
        int randomnum = (int)random;
        int[] testData = generateIntArray(randomnum);
        System.out.println("Generated Array:");
        printArray(testData);

        // Test the previous task with the generated array
        rearrangeArray(testData);
        System.out.println("After rearranging:");
        printArray(testData);
    }

    public static int[] generateIntArray(int size) {
        int[] array = new int[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            array[i] = random.nextInt(10); // Generates random integers between 0 and 99
        }
        return array;
    }

    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    public static void rearrangeArray(int[] arr) {
        int index = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != 0) {
                arr[index++] = arr[i];
            }
        }
        while (index < arr.length) {
            arr[index++] = 0;
        }
    }
}


package movezerotoend;


import java.util.Arrays;
import java.util.Scanner;

public class RearrangeArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Prompt the user to enter the array elements separated by commas
        System.out.println("Enter the array elements separated by commas: ");
        String input = scanner.nextLine();
        
        // Split the input string into an array of strings
        String[] elements = input.split(",");
        
        // Create an array and parse the input elements into integers
        int[] arr = new int[elements.length];
        for (int i = 0; i < elements.length; i++) {
            arr[i] = Integer.parseInt(elements[i].trim());
        }
        rearrangeArray(arr);
        System.out.println("After rearranging: " + Arrays.toString(arr));
    }

    public static void rearrangeArray(int[] arr) {
        int index = 0;
        
        // Traverse the array
        for (int i = 0; i < arr.length; i++) {
            // If the current element is non-zero, move it to the front of the array
            if (arr[i] != 0) {
                arr[index++] = arr[i];
            }
        }
        
        // Fill the remaining elements with zeros
        while (index < arr.length) {
            arr[index++] = 0;
        }
    }
}

   

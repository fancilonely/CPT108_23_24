package xjtlu.cpt108.game2048;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class FreeSpaceTest extends ModelTestBase {

	private static final int numOfRows = 4;
	private static final int numOfColumns = 4;

	private static final int numOfInitialTiles = 0;

	@Override
	protected int getNumberOfRows() {
		return numOfRows;
	}

	@Override
	protected int getNumberOfColumns() {
		return numOfColumns;
	}

	@Override
	protected int getNumberOfInitialTiles() {
		return numOfInitialTiles;
	}

	@Test
	public void testEmptyBoardTest() {
		assertFalse(model.isFull());
	}

	@Test
	public void testNoEmptySpace() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns; j++) {
				model.setTile(i, j, Tile.VALUE_INDEX[8]);
			}
		}
		assertTrue(model.isFull());
	}

	@Test
	public void testEmptyTopRowTest() {
		for (int i = 1; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns; j++) {
				model.setTile(i, j, Tile.VALUE_INDEX[8]);
			}
		}
		assertFalse(model.isFull());
	}

	@Test
	public void testEmptyMiddleRowTest() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns; j++) {
				model.setTile(i, j, Tile.VALUE_INDEX[8]);
			}
		}

		int rowToClear = numOfRows / 2;
		for (int j = 0; j < numOfColumns; j++) {
			model.clearTile(rowToClear, j);
		}
		assertFalse(model.isFull());
	}

	@Test
	public void testEmptyBottomRowTest() {
		for (int i = 0; i < numOfRows - 1; i++) {
			for (int j = 0; j < numOfColumns; j++) {
				model.setTile(i, j, Tile.VALUE_INDEX[8]);
			}
		}
		assertFalse(model.isFull());
	}

	@Test
	public void testEmptyLeftColumnTest() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 1; j < numOfColumns; j++) {
				model.setTile(i, j, Tile.VALUE_INDEX[8]);
			}
		}
		assertFalse(model.isFull());
	}

	@Test
	public void testEmptyMiddleColumnTest() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns - 1; j++) {
				model.setTile(i, j, Tile.VALUE_INDEX[8]);
			}
		}

		int columnToClear = numOfColumns / 2;
		for (int i = 0; i < numOfRows; i++) {
			model.clearTile(i, columnToClear);
		}
		assertFalse(model.isFull());
	}

	@Test
	public void testEmptyRightColumnTest() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns - 1; j++) {
				model.setTile(i, j, Tile.VALUE_INDEX[8]);
			}
		}
		assertFalse(model.isFull());
	}

	@Test
	public void testOneEmptySpaceTest() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns - 1; j++) {
				model.setTile(i, j, Tile.VALUE_INDEX[8]);
			}
		}
		model.setTile(numOfRows / 2, numOfColumns / 2, Model.FREE_TILE_VALUE);
		assertFalse(model.isFull());
	}

}

package xjtlu.cpt108.game2048.lang;

public interface Constants {

	int TILE_RADIUS = 15;
	int WIN_MARGIN = 20;
	int TILE_SIZE = 65;
	int TILE_MARGIN = 15;
	String FONT = "Tahoma";

	int ROWS = 4;
	int COLUMNS = 4;
	int INITIAL_TILES = 2;

	int WINNING_VALUE = 2048;

	int WINDOW_WIDTH = COLUMNS * (TILE_SIZE + TILE_MARGIN) + 0 * (TILE_MARGIN) + 55;
	int WINDOW_HEIGHT = ROWS * (TILE_SIZE + TILE_MARGIN) + 0 * (TILE_MARGIN) + 160;

}

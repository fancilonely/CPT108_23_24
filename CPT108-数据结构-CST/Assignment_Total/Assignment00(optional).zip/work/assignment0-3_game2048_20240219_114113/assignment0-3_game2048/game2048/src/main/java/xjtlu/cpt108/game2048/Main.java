package xjtlu.cpt108.game2048;

import xjtlu.cpt108.game2048.ui.Game;

public class Main {

	public static void main(String[] args) {
		new Game();
		Game.CONTROLS.bind();
	}

}

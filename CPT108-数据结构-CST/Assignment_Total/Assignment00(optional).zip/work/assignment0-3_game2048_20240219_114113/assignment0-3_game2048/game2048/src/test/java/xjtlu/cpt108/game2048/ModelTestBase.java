package xjtlu.cpt108.game2048;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.TestInfo;

import com.olek.junit.JunitTestBase;

import xjtlu.cpt108.game2048.Model.MoveDirection;

public abstract class ModelTestBase extends JunitTestBase {

	protected Model model = null;

	private int steps;
	private int score;

	@Override
	public void timeStart(TestInfo testInfo) {
		super.timeStart(testInfo);
		model = new Board(getNumberOfRows(), getNumberOfColumns(), getNumberOfInitialTiles());
		steps = 0;
		score = 0;
	}

	@Override
	public void timeEnd(TestInfo testInfo) {
		printErrorMessage("Model after test", model);
		super.timeEnd(testInfo);
	}

	protected abstract int getNumberOfRows();

	protected abstract int getNumberOfColumns();

	protected abstract int getNumberOfInitialTiles();

	protected void move(MoveDirection moveDirection) {
		move(moveDirection, false, 0);
	}

	protected void move(MoveDirection moveDirection, int scoreAdded) {
		move(moveDirection, true, scoreAdded);
	}

	private void move(MoveDirection moveDirection, boolean withScoreTest, int scoreAdded) {
		String moveString = null;
		switch (moveDirection) {
		case UP:
			moveString = "up";
			model.moveUp();
			break;
		case DOWN:
			moveString = "down";
			model.moveDown();
			break;
		case LEFT:
			moveString = "left";
			model.moveLeft();
			break;
		case RIGHT:
			moveString = "right";
			model.moveRight();
			break;
		default:
		}
		score += scoreAdded;
		if (withScoreTest) {
			printMessage(String.format("%d. Move %s, expected new score: %d", ++steps, moveString, score), model);
		} else {
			printMessage(String.format("%d. Move %s", ++steps, moveString), model);
		}
		if (withScoreTest) assertEquals(score, model.getScore());
	}

}

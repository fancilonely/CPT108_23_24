/**
 * Module declaration.
 */
module xjtlu.cpt108.game2048 {
	requires transitive java.desktop;
	requires com.olek.app.commons;
	// requires transitive xjtlu.cpt108.commons;

	exports xjtlu.cpt108.game2048;
}

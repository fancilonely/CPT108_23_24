package xjtlu.cpt108.game2048;

import java.awt.Color;
import java.io.Serializable;
import java.util.Random;

import xjtlu.cpt108.game2048.ui.Colors;

public class Tile implements Cloneable, Serializable {

	private static final long serialVersionUID = 1L;

	public static final int[] VALUE_INDEX = Colors.COLOR_SCHEME.keySet().stream().mapToInt(Integer::intValue).toArray();

	private static final Random random = new Random(System.currentTimeMillis());

	public static int getRandomValue(int maxValue) {
		if (maxValue < VALUE_INDEX[0]) throw new IllegalArgumentException("max value cannot be smaller than " + VALUE_INDEX[0]);
		int ind;
		do {
			ind = random.nextInt(VALUE_INDEX.length);
		} while (VALUE_INDEX[ind] <= FREE_TILE_VALUE || VALUE_INDEX[ind] > maxValue);
		return VALUE_INDEX[ind];
	}

	public static int getTileValueWithIndex(int index) {
		if (index < 0) throw new IllegalArgumentException("index cannot be negative!");
		if (index > getTileValueMaxIndex()) throw new IllegalArgumentException("index cannot be greater than " + (getTileValueMaxIndex()));

		return VALUE_INDEX[index];
	}

	public static int getTileValueMaxIndex() {
		return Colors.COLOR_SCHEME.size() - 1;
	}

	public static int getTileMaxValue() {
		return VALUE_INDEX[VALUE_INDEX.length - 1];
	}

	public static int getTileMinValue() {
		return VALUE_INDEX[0];
	}

	private static final int DEFAULT_MIN_VALUE = VALUE_INDEX[0];

	private static int FREE_TILE_VALUE = DEFAULT_MIN_VALUE;

	public static final void setFreeTileValue(int freeTileValue) {
		FREE_TILE_VALUE = freeTileValue;
	}

	private int row;
	private int column;
	private int value;

	public Tile(int value) {
		this(0, 0, value);
	}

	public Tile(int row, int column) {
		this(row, column, FREE_TILE_VALUE);
	}

	public Tile(int row, int column, int tileMeta) {
		setRow(row);
		setColumn(column);
		setValue(tileMeta);
	}

	public Tile(Tile tile) {
		this(tile.row, tile.column, tile.value);
	}

	/**
	 * Merge the tile value if they are equal.
	 * 
	 * @param tile Tile to be merged
	 * @return new value of the tile
	 */
	public int merge(Tile tile) {
		if (this.value != tile.value)
			throw new IllegalArgumentException(String.format("merged values is not valid: %d, %d", value, tile.value));

		this.value += tile.value;
		return this.value;
	}

	@Override
	public Tile clone() {
		return new Tile(this);
	}

	public boolean hasSameValue(Tile tile) {
		return value == tile.value;
	}

	public void setPosition(int row, int column) {
		setRow(row);
		setColumn(column);
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		if (FREE_TILE_VALUE > value) throw new IllegalArgumentException("value must be greater than or equal to " + FREE_TILE_VALUE);
		double l = Math.log(Double.parseDouble("" + value)) / Math.log(2);
		double f = Math.floor(l);
		double c = Math.ceil(l);
		if (f != c) throw new IllegalArgumentException("value must be a power of 2: " + "" + value);
		this.value = value;
	}

	public Color getTileColor() {
		return value < 16 ? Colors.BRIGHT : Colors.LIGHT;
	}

	public Color getBgColor() {
		if (value <= FREE_TILE_VALUE) return Colors.COLOR_SCHEME.get(FREE_TILE_VALUE);
		return Colors.COLOR_SCHEME.floorEntry(value).getValue();
		// return COLOR_SCHEME.get(value);
	}

	public String toString(boolean valueOnly) {
		return valueOnly ? String.format("Tile: value=%d", value) //
				: String.format("Tile[%i,%i]: %s", row, column, value);
	}

	@Override
	public String toString() {
		return toString(false);
	}

}

package xjtlu.cpt108.game2048;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public abstract class Model {

	private static final Random random = new Random(System.currentTimeMillis());

	protected static String LINE_SEPARATOR = System.getProperty("line.separator");

	public static enum MoveDirection {
		UP, DOWN, LEFT, RIGHT;
	}

	protected static int FREE_TILE_VALUE = Tile.VALUE_INDEX[0];
	private static int NEW_TILE_MAX_VALUE = Tile.VALUE_INDEX[4];

	public static final int getFreeTileValue() {
		return FREE_TILE_VALUE;
	}

	private int numOfRows;
	private int numOfColumns;
	private int numOfInitialTiles;

	private Tile[] tiles;

	private int score;
	private int winningTileValue;

	private int steps;

	private boolean isAlreadyFull;
	private String gameStatus;
	private boolean stateChanged = false;

	protected Model(int numOfRows, int numOfColumns, int numOfInitialTiles, int winningTileValue) {
		setNumOfRows(numOfRows);
		setNumOfColumns(numOfColumns);
		setNumOfInitialTiles(numOfInitialTiles);
		setWinningTileValue(winningTileValue);
		start();
	}

	private void start() {
		reset();
	}

	public void reset() {
		initialize();

		StringBuilder sb = new StringBuilder();
		sb.append("Game 2048") //
				.append(LINE_SEPARATOR).append("num of rows: ").append(numOfRows) //
				.append(", num of columns: ").append(numOfColumns) //
				.append(LINE_SEPARATOR).append("num of initial tiles: ").append(numOfInitialTiles) //
				.append(LINE_SEPARATOR).append("winning tile value: ").append(winningTileValue) //
		;

		System.out.println(sb.toString());

		generateInitialTiles();
	}

	private void initialize() {
		int numOfTiles = numOfRows * numOfColumns;
		Tile[] tiles = new Tile[numOfTiles];
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns; j++) {
				tiles[i * numOfColumns + j] = getNewTile(i, j, FREE_TILE_VALUE);
			}
		}
		setTiles(tiles);

		setScore(0);
		setSteps(0);
		setGameStatus("");

		isAlreadyFull = false;
	}

	private Tile getNewTile(int ind, int tileValue) {
		return getNewTile(ind / numOfColumns, ind % numOfColumns, tileValue);
	}

	private Tile getNewTile(int row, int column, int tileValue) {
		return new Tile(row, column, tileValue);
	}

	private void generateInitialTiles() {
		addNewTilesToBoard(numOfInitialTiles);
	}

	private boolean isAddNewTile() {
		if (stateChanged) return false;
		return random.nextInt(10) > 2;
	}

	private void addNewTilesToBoard(int numOfNewTiles) {
		if (numOfNewTiles < 1) return;
		List<Integer> freeTiles = getFreeTiles();
		if (freeTiles.isEmpty()) return;
		for (int i = 0; i < numOfNewTiles; i++) {
			int freeTileIndex = random.nextInt(freeTiles.size());
			int tileInd = freeTiles.get(freeTileIndex);
			int tileValue = Tile.getRandomValue(NEW_TILE_MAX_VALUE);

			setTile(getNewTile(tileInd, tileValue));
			freeTiles.remove(freeTileIndex);
		}
	}

	protected int getIndex(int row, int column) {
		return isValidIndex(row * numOfColumns + column);
	}

	private int isValidIndex(int ind) {
		if (ind < 0 || ind >= tiles.length) throw new IllegalArgumentException("tiles index out of range: " + ind);
		return ind;
	}

	public boolean isGameOver() {
		if (hasWinner()) {
			setGameStatus("Win!!");
		} else if (isFull()) {
			if (isAlreadyFull) {
				System.out.println("isGameOver: lost due to no free tile to fill!");
				setGameStatus("Lost!!");
			} else if (!hasPossibleMove()) {
				System.out.println("isGameOver: lost due to no more move!");
				setGameStatus("Lost!!");
			}
		}
		if (!gameStatus.isBlank()) return true;

		// randomly add new tile to the board
		if (isAddNewTile()) {
			addNewTilesToBoard(1);
			isAlreadyFull = isFull();
		}

		return false;
	}

	private int move(MoveDirection moveDirection) {
		if (null == moveDirection) throw new IllegalArgumentException("Move direction cannot be null!");
		steps++;
		List<List<Integer>> sequences = generateAccessSequences(moveDirection);
		return mergeAllTiles(sequences);
	}

	public int moveUp() {
		return move(MoveDirection.UP);
	}

	public int moveDown() {
		return move(MoveDirection.DOWN);
	}

	public int moveLeft() {
		return move(MoveDirection.LEFT);
	}

	public int moveRight() {
		return move(MoveDirection.RIGHT);
	}

	protected List<List<Integer>> generateAccessSequences(MoveDirection moveDirection) {
		int numOfColumns = getNumOfColumns();
		int numOfRows = getNumOfRows();

		List<List<Integer>> sequences = new ArrayList<>();
		switch (moveDirection) {
		case UP:
			for (int i = 0; i < numOfColumns; i++) {
				List<Integer> sequenceToMerge = new ArrayList<>();
				for (int j = 0; j < numOfRows; j++) {
					sequenceToMerge.add(j * numOfColumns + i);
				}
				sequences.add(sequenceToMerge);
			}
			break;
		case DOWN:
			for (int i = 0; i < numOfColumns; i++) {
				List<Integer> sequenceToMerge = new ArrayList<>();
				for (int j = numOfRows - 1; j >= 0; j--) {
					sequenceToMerge.add(j * numOfColumns + i);
				}
				sequences.add(sequenceToMerge);
			}
			break;
		case LEFT:
			for (int i = 0; i < numOfRows; i++) {
				List<Integer> sequenceToMerge = new ArrayList<>();
				for (int j = i * numOfColumns; j < (i + 1) * numOfColumns; j++) {
					sequenceToMerge.add(j);
				}
				sequences.add(sequenceToMerge);
			}
			break;
		case RIGHT:
			for (int i = 0; i < numOfRows; i++) {
				List<Integer> sequenceToMerge = new ArrayList<>();
				for (int j = (i + 1) * numOfColumns - 1; j >= i * numOfColumns; j--) {
					sequenceToMerge.add(j);
				}
				sequences.add(sequenceToMerge);
			}
			break;
		};

		return sequences;
	}

	private int mergeAllTiles(List<List<Integer>> sequences) {
		int scoreAdded = 0;
		stateChanged = false;
		for (List<Integer> sequenceToMerge : sequences) {
			scoreAdded += mergeTiles(sequenceToMerge);
		}
		return scoreAdded;
	}

	/**
	 * Return the indices of tiles that are free
	 * 
	 * @return Indices of tiles that are free
	 */
	protected List<Integer> getFreeTiles() {
		List<Integer> freeTiles = new ArrayList<>();
		for (int i = 0; i < tiles.length; i++) {
			if (isFreeTile(i)) freeTiles.add(i);
		}
		return freeTiles;
	}

	public Tile getTile(int row, int column) {
		return getTile(getIndex(row, column));
	}

	public Tile getTile(int ind) {
		isValidIndex(ind);
		return tiles[ind];
	}

	public Tile setTile(int row, int column, int value) {
		return setTile(getNewTile(getIndex(row, column), value));
	}

	public Tile setTile(int ind, int value) {
		return setTile(getNewTile(ind, value));
	}

	protected Tile setTile(Tile tile) {
		int ind = getIndex(tile.getRow(), tile.getColumn());
		isValidIndex(ind);
		this.tiles[ind] = tile;
		return tile;
	}

	public Tile clearTile(int row, int column) {
		return clearTile(getIndex(row, column));
	}

	protected Tile clearTile(int ind) {
		isValidIndex(ind);
		Tile origTile = tiles[ind];
		tiles[ind] = getNewTile(ind, FREE_TILE_VALUE);
		return origTile;
	}

	protected boolean isFreeTile(int row, int column) {
		return isFreeTile(getIndex(row, column));
	}

	protected boolean isFreeTile(int ind) {
		isValidIndex(ind);
		return FREE_TILE_VALUE >= tiles[ind].getValue();
	}

	protected boolean isStateChanged() {
		return stateChanged;
	}

	protected void setStateChanged(boolean stateChanged) {
		this.stateChanged = stateChanged;
	}

	public int getNumOfRows() {
		return numOfRows;
	}

	public void setNumOfRows(int numOfRows) {
		if (0 >= numOfRows) throw new IllegalArgumentException("number of rows must be greater than zero!");
		this.numOfRows = numOfRows;
	}

	public int getNumOfColumns() {
		return numOfColumns;
	}

	public void setNumOfColumns(int numOfColumns) {
		if (0 >= numOfColumns) throw new IllegalArgumentException("number of column must be greater than zero!");
		this.numOfColumns = numOfColumns;
	}

	protected int getTotalNumOfTiles() {
		return numOfRows * numOfColumns;
	}

	public int getNumOfInitialTiles() {
		return numOfInitialTiles;
	}

	public void setNumOfInitialTiles(int numOfInitialTiles) {
		if (0 > numOfInitialTiles) throw new IllegalArgumentException("number of initial tiles must be greater than zero!");
		this.numOfInitialTiles = numOfInitialTiles;
	}

	/**
	 * Return the set of board tiles
	 * 
	 * @return The set of board tiles
	 */
	public Tile[] getTiles() {
		return tiles;
	}

	private void setTiles(Tile[] tiles) {
		this.tiles = tiles;
	}

	public int getScore() {
		return score;
	}

	protected void setScore(int score) {
		this.score = score;
	}

	/**
	 * Accumulate the score
	 * 
	 * @param tile score to be added
	 * @return score added
	 */
	protected int addScore(int scoreAdded) {
		this.score += scoreAdded;
		return scoreAdded;
	}

	public int getWinningTileValue() {
		return winningTileValue;
	}

	public void setWinningTileValue(int winningTileValue) {
		if (0 >= winningTileValue) throw new IllegalArgumentException("winning tile value must be greater than zero!");
		if (FREE_TILE_VALUE >= winningTileValue)
			throw new IllegalArgumentException("winning tile value must have value greater than " + FREE_TILE_VALUE);
		this.winningTileValue = winningTileValue;
	}

	public int getSteps() {
		return steps;
	}

	private void setSteps(int steps) {
		this.steps = steps;
	}

	public String getGameStatus() {
		return gameStatus;
	}

	private void setGameStatus(String gameStatus) {
		this.gameStatus = null == gameStatus ? "" : gameStatus.strip();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < numOfRows; i++) {
			sb.append("\n|");
			for (int j = 0; j < numOfColumns; j++) {
				sb.append(String.format(" %4d", tiles[getIndex(i, j)].getValue())) //
						.append(" |");
			}
		}
		StringBuilder sbFrame = new StringBuilder();
		for (int i = 0; i < numOfColumns; i++) {
			sbFrame.append("+------");
		}
		sbFrame.append("+");
		sb.insert(0, sbFrame.toString()).append("\n").append(sbFrame.toString());
		sb.append("\nScore: ").append(score);
		sb.append("\nSteps: ").append(steps);
		return sb.toString();
	}

	protected abstract boolean isFull();

	protected abstract boolean hasWinner();

	protected abstract boolean hasPossibleMove();

	protected abstract int mergeTiles(List<Integer> sequenceToCheck);

}

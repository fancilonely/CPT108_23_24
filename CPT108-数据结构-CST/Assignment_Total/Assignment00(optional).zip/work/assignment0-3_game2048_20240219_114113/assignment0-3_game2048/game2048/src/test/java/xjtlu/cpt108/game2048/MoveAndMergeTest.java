package xjtlu.cpt108.game2048;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import xjtlu.cpt108.game2048.Model.MoveDirection;

public class MoveAndMergeTest extends ModelTestBase {

	private static final int numOfRows = 4;
	private static final int numOfColumns = 4;

	private static final int numOfInitialTiles = 0;

	@Override
	protected int getNumberOfRows() {
		return numOfRows;
	}

	@Override
	protected int getNumberOfColumns() {
		return numOfColumns;
	}

	@Override
	protected int getNumberOfInitialTiles() {
		return numOfInitialTiles;
	}

	@Test
	public void testVerticalMove() {
		model.setTile(0, 0, Tile.VALUE_INDEX[1]);
		model.setTile(2, 1, Tile.VALUE_INDEX[1]);
		model.setTile(2, 2, Tile.VALUE_INDEX[1]);
		model.setTile(2, 3, Tile.VALUE_INDEX[1]);
		printMessage("Initial board", model);

		move(MoveDirection.UP);
		for (int i = 0; i < numOfColumns; i++) {
			assertEquals(Tile.VALUE_INDEX[1], model.getTile(0, i).getValue());
			assertTrue(model.isFreeTile(1, i));
		}

		move(MoveDirection.DOWN);
		for (int i = 0; i < numOfColumns; i++) {
			assertEquals(Tile.VALUE_INDEX[1], model.getTile(numOfRows - 1, i).getValue());
			assertTrue(model.isFreeTile(numOfRows - 2, i));
		}

		move(MoveDirection.UP);
		for (int i = 0; i < numOfColumns; i++) {
			assertEquals(Tile.VALUE_INDEX[1], model.getTile(0, i).getValue());
			assertTrue(model.isFreeTile(1, i));
		}
	}

	@Test
	public void testHorizontalMove() {
		model.setTile(0, 2, Tile.VALUE_INDEX[1]);
		model.setTile(1, 2, Tile.VALUE_INDEX[1]);
		model.setTile(2, 2, Tile.VALUE_INDEX[1]);
		model.setTile(3, 2, Tile.VALUE_INDEX[1]);
		printMessage("Initial board", model);

		move(MoveDirection.LEFT);
		for (int i = 0; i < numOfRows; i++) {
			assertEquals(Tile.VALUE_INDEX[1], model.getTile(i, 0).getValue());
			assertTrue(model.isFreeTile(i, 1));
		}

		move(MoveDirection.RIGHT);
		for (int i = 0; i < numOfRows; i++) {
			assertEquals(Tile.VALUE_INDEX[1], model.getTile(i, numOfColumns - 1).getValue());
			assertTrue(model.isFreeTile(i, numOfColumns - 2));
		}

		move(MoveDirection.LEFT);
		for (int i = 0; i < numOfRows; i++) {
			assertEquals(Tile.VALUE_INDEX[1], model.getTile(i, 0).getValue());
			assertTrue(model.isFreeTile(i, 1));
		}
	}

	@Test
	public void testRandomMove() {
		model.setTile(1, 1, Tile.VALUE_INDEX[1]);
		model.setTile(2, 1, Tile.VALUE_INDEX[1]);
		model.setTile(2, 2, Tile.VALUE_INDEX[1]);
		model.setTile(2, 3, Tile.VALUE_INDEX[1]);
		printMessage("Initial board", model);

		move(MoveDirection.LEFT);
		assertEquals(Tile.VALUE_INDEX[1], model.getTile(1, 0).getValue());
		assertEquals(Tile.VALUE_INDEX[2], model.getTile(2, 0).getValue());
		assertEquals(Tile.VALUE_INDEX[1], model.getTile(2, 1).getValue());
		assertTrue(model.isFreeTile(1, 1));
		assertTrue(model.isFreeTile(2, 2));

		move(MoveDirection.UP);
		assertEquals(Tile.VALUE_INDEX[1], model.getTile(0, 0).getValue());
		assertEquals(Tile.VALUE_INDEX[1], model.getTile(0, 1).getValue());
		assertEquals(Tile.VALUE_INDEX[2], model.getTile(1, 0).getValue());
		assertTrue(model.isFreeTile(0, 2));
		assertTrue(model.isFreeTile(1, 1));
		assertTrue(model.isFreeTile(2, 0));

		move(MoveDirection.RIGHT);
		assertEquals(Tile.VALUE_INDEX[2], model.getTile(0, 3).getValue());
		assertEquals(Tile.VALUE_INDEX[2], model.getTile(1, 3).getValue());
		assertTrue(model.isFreeTile(0, 2));
		assertTrue(model.isFreeTile(1, 2));
		assertTrue(model.isFreeTile(2, 3));

		move(MoveDirection.DOWN);
		assertEquals(Tile.VALUE_INDEX[3], model.getTile(3, 3).getValue());
		assertTrue(model.isFreeTile(1, 3));
		assertTrue(model.isFreeTile(2, 2));
		assertTrue(model.isFreeTile(2, 3));
		assertTrue(model.isFreeTile(3, 2));
		assertTrue(model.isFreeTile(3, 1));
	}

}

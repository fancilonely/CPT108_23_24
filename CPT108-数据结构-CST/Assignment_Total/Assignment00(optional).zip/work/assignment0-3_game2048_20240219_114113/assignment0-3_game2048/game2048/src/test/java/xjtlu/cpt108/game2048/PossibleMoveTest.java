package xjtlu.cpt108.game2048;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class PossibleMoveTest extends ModelTestBase {

	private static final int numOfRows = 4;
	private static final int numOfColumns = 4;

	private static final int numOfInitialTiles = 0;

	private static int TILE_MAX_INDEX = Tile.getTileValueMaxIndex() + 1;

	@Override
	protected int getNumberOfRows() {
		return numOfRows;
	}

	@Override
	protected int getNumberOfColumns() {
		return numOfColumns;
	}

	@Override
	protected int getNumberOfInitialTiles() {
		return numOfInitialTiles;
	}

	@Test
	public void testFreeBoardTest() {
		assertTrue(model.hasPossibleMove());
	}

	@Test
	public void testNoFreeSpace() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns; j++) {
				int tileInd = (i * numOfColumns + j) % (TILE_MAX_INDEX - 1) + 1;
				model.setTile(i, j, Tile.getTileValueWithIndex(tileInd));
			}
		}
		assertTrue(model.isFull());
		assertFalse(model.hasPossibleMove());
	}

	@Test
	public void testPossibleVeritcalMoveInMiddle() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns; j++) {
				int tileInd = (i * numOfColumns + j) % (TILE_MAX_INDEX - 1) + 1;
				model.setTile(i, j, Tile.getTileValueWithIndex(tileInd));
			}
		}
		int row = numOfRows / 2;
		int column = numOfColumns / 2;
		model.setTile(row, column, 16);
		model.setTile(row - 1, column, 16);
		assertTrue(model.isFull());
		assertTrue(model.hasPossibleMove());
	}

	@Test
	public void testPossibleHorizontalMoveInMiddle() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns; j++) {
				int tileInd = (i * numOfColumns + j) % (TILE_MAX_INDEX - 1) + 1;
				model.setTile(i, j, Tile.getTileValueWithIndex(tileInd));
			}
		}
		int row = numOfRows / 2;
		int column = numOfColumns / 2;
		model.setTile(row, column, 16);
		model.setTile(row, column - 1, 16);
		assertTrue(model.isFull());
		assertTrue(model.hasPossibleMove());
	}
}

package xjtlu.cpt108.game2048.ui;

import java.awt.Color;
import java.util.NavigableMap;
import java.util.TreeMap;

public interface Colors {

	public final static Color WINBG = new Color(0XFAF8EF);
	public final static Color GRIDBG = new Color(0XBBADA0);

	public final static Color BRIGHT = new Color(0X776E65);
	public final static Color LIGHT = new Color(0XF9F6F2);

	public static final NavigableMap<Integer, Color> COLOR_SCHEME = new TreeMap<>() {
		private static final long serialVersionUID = 1L;
		{
			put(1, new Color(238, 228, 218, 90));
			put(2, new Color(0XEEE4DA));
			put(4, new Color(0XEDE0C8));
			put(8, new Color(0XF2B179));
			put(16, new Color(0XF59563));
			put(32, new Color(0XF67C5F));
			put(64, new Color(0XF65E3B));
			put(128, new Color(0XEDCF72));
			put(256, new Color(0XEDCC61));
			put(512, new Color(0XEDC850));
			put(1024, new Color(0XEDC53F));
			put(2048, new Color(0XEDC22E));
		}
	};

}

package xjtlu.cpt108.game2048.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JPanel;

import xjtlu.cpt108.game2048.Model;
import xjtlu.cpt108.game2048.Tile;
import xjtlu.cpt108.game2048.lang.Constants;

public class Grid extends JPanel implements Constants {
	private static final long serialVersionUID = 1L;

	public Grid() {
		super(true); // turn on doublebuffering
	}

	public void paintComponent(Graphics g2) {
		super.paintComponent(g2);

		Graphics2D g = ((Graphics2D) g2); // cast to get context for drawing

		/* turn on antialiasing for smooth and non-pixelated edges */
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

		drawBackground(g);
		drawTitle(g);
		drawScoreBoard(g);
		drawBoard(g);

		g.dispose(); // release memory
	}

	private static void drawTitle(Graphics g) {
		g.setFont(new Font(FONT, Font.BOLD, 38));
		g.setColor(Colors.BRIGHT);
		g.drawString(String.valueOf(Game.BOARD.getWinningTileValue()), WIN_MARGIN, 50);
	}

	private void drawScoreBoard(Graphics2D g) {
		int width = 80;
		int height = 40;
		int xOffset = Game.WINDOW.getWidth() - WIN_MARGIN - width;
		int yOffset = 20;
		g.fillRoundRect(xOffset, yOffset, width, height, TILE_RADIUS, TILE_RADIUS);
		g.setFont(new Font(FONT, Font.BOLD, 10));
		g.setColor(new Color(0XFFFFFF));
		g.drawString("SCORE", xOffset + 22, yOffset + 15);
		g.setFont(new Font(FONT, Font.BOLD, 12));
		g.drawString(String.valueOf(Game.BOARD.getScore()), xOffset + 35, yOffset + 30);
	}

	private static void drawBackground(Graphics g) {
		g.setColor(Colors.WINBG);
		g.fillRect(0, 0, Game.WINDOW.getWidth(), Game.WINDOW.getHeight());
	}

	private static void drawBoard(Graphics g) {
		Tile[] tiles = Game.BOARD.getTiles();
		int numOfRows = Game.BOARD.getNumOfRows();
		int numOfColumns = Game.BOARD.getNumOfColumns();

		int boardHeight = numOfRows * (TILE_SIZE + TILE_MARGIN);
		g.translate(WIN_MARGIN, 80);
		g.setColor(Colors.GRIDBG);
		g.fillRoundRect(0, 0, Game.WINDOW.getWidth() - (WIN_MARGIN * 2), boardHeight + TILE_MARGIN, TILE_RADIUS, TILE_RADIUS);

		for (int row = 0; row < numOfRows; row++) {
			for (int col = 0; col < numOfColumns; col++) {
				drawTile(g, tiles[row * numOfColumns + col], col, row);
			}
		}

		String gameStatus = Game.BOARD.getGameStatus();
		if (null != gameStatus && !gameStatus.isBlank()) {
			g.setColor(new Color(255, 255, 255, 40));
			g.fillRect(0, 0, Game.WINDOW.getWidth(), Game.WINDOW.getHeight());
			g.setColor(Colors.BRIGHT);
			g.setFont(new Font(FONT, Font.BOLD, 30));
			g.drawString("You " + gameStatus + "!", 68, 150);
			Game.CONTROLS.unbind();
		}
	}

	private static void drawTile(Graphics g, Tile tile, int x, int y) {
		int xOffset = x * (TILE_MARGIN + TILE_SIZE) + TILE_MARGIN;
		int yOffset = y * (TILE_MARGIN + TILE_SIZE) + TILE_MARGIN;

		g.setColor(tile.getBgColor());
		g.fillRoundRect(xOffset, yOffset, TILE_SIZE, TILE_SIZE, TILE_RADIUS, TILE_RADIUS);

		int value = null == tile ? Model.getFreeTileValue() : tile.getValue();
		if (value <= Model.getFreeTileValue()) return;

		g.setColor(tile.getTileColor());

		final int size = value < 100 ? 36 : value < 1000 ? 32 : 24;
		final Font font = new Font(FONT, Font.BOLD, size);
		g.setFont(font);

		String s = String.valueOf(value);
		final FontMetrics fm = g.getFontMetrics(font);

		final int w = fm.stringWidth(s);
		final int h = -(int) fm.getLineMetrics(s, g).getBaselineOffsets()[2];

		g.drawString(s, xOffset + (TILE_SIZE - w) / 2, yOffset + TILE_SIZE - (TILE_SIZE - h) / 2 - 2);
	}
}

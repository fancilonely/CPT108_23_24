package xjtlu.cpt108.game2048;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import xjtlu.cpt108.game2048.Model.MoveDirection;

public class ScoreUpdateTest extends ModelTestBase {

	private static final int numOfRows = 4;
	private static final int numOfColumns = 4;

	private static final int numOfInitialTiles = 0;

	@Override
	protected int getNumberOfRows() {
		return numOfRows;
	}

	@Override
	protected int getNumberOfColumns() {
		return numOfColumns;
	}

	@Override
	protected int getNumberOfInitialTiles() {
		return numOfInitialTiles;
	}

	@Test
	public void testEmptyBoardTest() {
		assertEquals(0, model.getScore());
	}

	@Test
	public void testScoreAfterMerge() {
		model.setTile(1, 1, Tile.VALUE_INDEX[1]);
		model.setTile(2, 1, Tile.VALUE_INDEX[1]);
		model.setTile(2, 2, Tile.VALUE_INDEX[1]);
		model.setTile(2, 3, Tile.VALUE_INDEX[1]);
		printMessage("Initial board", model);

		move(MoveDirection.LEFT, 4);
		move(MoveDirection.UP, 0);
		move(MoveDirection.RIGHT, 4);
		move(MoveDirection.DOWN, 8);
	}

}

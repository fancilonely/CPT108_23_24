package xjtlu.cpt108.game2048;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class WinnerTest extends ModelTestBase {

	private static final int numOfRows = 4;
	private static final int numOfColumns = 4;

	private static final int numOfInitialTiles = 0;

	private static int TILE_MAX_INDEX = Tile.getTileValueMaxIndex() + 1;

	@Override
	protected int getNumberOfRows() {
		return numOfRows;
	}

	@Override
	protected int getNumberOfColumns() {
		return numOfColumns;
	}

	@Override
	protected int getNumberOfInitialTiles() {
		return numOfInitialTiles;
	}

	@Test
	public void testEmptyBoard() {
		assertFalse(model.hasWinner());
	}

	@Test
	public void testNoEmptySpace() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns; j++) {
				int tileInd = (i * numOfColumns + j) % (TILE_MAX_INDEX - 2) + 1;
				model.setTile(i, j, Tile.getTileValueWithIndex(tileInd));
			}
		}
		assertFalse(model.hasWinner());
	}

	@Test
	public void testHasOneWinner() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns; j++) {
				int tileInd = (i * numOfColumns + j) % (TILE_MAX_INDEX - 2) + 1;
				model.setTile(i, j, Tile.getTileValueWithIndex(tileInd));
			}
		}
		int row = numOfRows / 2;
		int column = numOfColumns / 2;
		model.setTile(row, column, model.getWinningTileValue());
		System.out.println(model.toString());
		assertTrue(model.hasWinner());
	}

	@Test
	public void testHasMultipleWinners() {
		for (int i = 0; i < numOfRows; i++) {
			for (int j = 0; j < numOfColumns; j++) {
				int tileInd = (i * numOfColumns + j) % (TILE_MAX_INDEX - 2) + 1;
				model.setTile(i, j, Tile.getTileValueWithIndex(tileInd));
			}
		}
		int row = numOfRows / 2;
		int column = numOfColumns / 2;
		model.setTile(row, column, model.getWinningTileValue());
		model.setTile(row - 1, column, model.getWinningTileValue());
		System.out.println(model.toString());
		assertTrue(model.hasWinner());
	}

}

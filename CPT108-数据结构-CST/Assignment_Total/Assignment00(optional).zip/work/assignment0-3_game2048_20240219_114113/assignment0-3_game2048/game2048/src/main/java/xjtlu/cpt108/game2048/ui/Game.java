package xjtlu.cpt108.game2048.ui;

import xjtlu.cpt108.game2048.Board;
import xjtlu.cpt108.game2048.lang.Constants;

public class Game {

	public static final Window WINDOW = new Window("2048");
	public static final Controls CONTROLS = new Controls();
	public static final Board BOARD = new Board(Constants.ROWS, Constants.COLUMNS, Constants.INITIAL_TILES, Constants.WINNING_VALUE);

}

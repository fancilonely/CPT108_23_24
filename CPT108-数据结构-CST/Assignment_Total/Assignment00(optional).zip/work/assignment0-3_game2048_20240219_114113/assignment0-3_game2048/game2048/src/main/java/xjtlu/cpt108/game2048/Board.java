package xjtlu.cpt108.game2048;

import java.util.List;

import xjtlu.cpt108.game2048.lang.Constants;

public class Board extends Model {

	public Board() {
		this(Constants.ROWS, Constants.COLUMNS, Constants.INITIAL_TILES);
	}

	public Board(int size) {
		this(size, size, Constants.INITIAL_TILES);
	}

	public Board(int numOfRows, int numOfColumns, int numOfInitialTiles) {
		this(numOfRows, numOfColumns, numOfInitialTiles, Tile.getTileMaxValue());
	}

	public Board(int numOfRows, int numOfColumns, int numOfInitialTiles, int winningTileValue) {
		super(numOfRows, numOfColumns, numOfInitialTiles, winningTileValue);
	}

	@Override
	protected boolean isFull() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected boolean hasWinner() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected boolean hasPossibleMove() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected int mergeTiles(List<Integer> sequenceToCheck) {
		// TODO Auto-generated method stub
		return 0;
	}

}
